
import './App.css'
 import Scholarships from './Scholarships/Scholarships'


function App() {
  

  return (
    <>
      <Scholarships/>
      
    </>
  )
}

export default App
